--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.0 (Debian 15.0-1.pgdg110+1)
-- Dumped by pg_dump version 15.0 (Debian 15.0-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE softbot;
--
-- Name: softbot; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE softbot WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE softbot OWNER TO postgres;

\connect softbot

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: create_constraint_if_not_exists(text, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_constraint_if_not_exists(t_name text, c_name text, constraint_sql text) RETURNS void
    LANGUAGE plpgsql
    AS $$
begin
    -- Look for our constraint
    if not exists (select constraint_name 
                   from information_schema.constraint_column_usage 
                   where table_name = t_name  and constraint_name = c_name) then
        execute constraint_sql;
    end if;
end;
$$;


ALTER FUNCTION public.create_constraint_if_not_exists(t_name text, c_name text, constraint_sql text) OWNER TO postgres;

--
-- Name: get_last_tasks_of_everyone(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_last_tasks_of_everyone() RETURNS TABLE(slack_id text, lsat_in timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE
    r RECORD;
	s RECORD;
BEGIN
	--RETURN QUERY SELECT attendance.slack_id AS slack_id, max(attendance.in_time) AS last_in FROM attendance GROUP BY attendance.slack_id;
	
	FOR r IN SELECT attendance.slack_id AS slack_id, MAX(attendance.in_time) AS last_in 
	FROM attendance GROUP BY attendance.slack_id
	LOOP
		SELECT attendance.slack_id AS slack_id, attendance.in_time AS last_in 
		FROM attendance INTO s 
		WHERE attendance.slack_id=r.slack_id AND attendance.in_time=r.last_in;
		RAISE NOTICE '%', r;
-- 		RETURN NEXT r;
	END LOOP;
-- 	RAISE NOTICE '%', s;
END $$;


ALTER FUNCTION public.get_last_tasks_of_everyone() OWNER TO postgres;

--
-- Name: trigger_set_timestamp(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.trigger_set_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.trigger_set_timestamp() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _attendanceToproject; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."_attendanceToproject" (
    "A" integer NOT NULL,
    "B" integer NOT NULL
);


ALTER TABLE public."_attendanceToproject" OWNER TO postgres;

--
-- Name: _attendanceTotask; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."_attendanceTotask" (
    "A" integer NOT NULL,
    "B" integer NOT NULL
);


ALTER TABLE public."_attendanceTotask" OWNER TO postgres;

--
-- Name: attendance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendance (
    id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    in_time timestamp(3) without time zone NOT NULL,
    out_time timestamp(3) without time zone,
    on_break boolean NOT NULL,
    participant_id integer NOT NULL
);


ALTER TABLE public.attendance OWNER TO postgres;

--
-- Name: attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attendance_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.attendance_id_seq OWNER TO postgres;

--
-- Name: attendance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attendance_id_seq OWNED BY public.attendance.id;


--
-- Name: blocker; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.blocker (
    id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    description text NOT NULL,
    project_id integer NOT NULL,
    participant_id integer NOT NULL
);


ALTER TABLE public.blocker OWNER TO postgres;

--
-- Name: blocker_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.blocker_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blocker_id_seq OWNER TO postgres;

--
-- Name: blocker_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.blocker_id_seq OWNED BY public.blocker.id;


--
-- Name: break_; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.break_ (
    id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    break_length interval NOT NULL,
    started timestamp(3) without time zone NOT NULL,
    ended timestamp(3) without time zone,
    attendance_id integer NOT NULL
);


ALTER TABLE public.break_ OWNER TO postgres;

--
-- Name: break__id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.break__id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.break__id_seq OWNER TO postgres;

--
-- Name: break__id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.break__id_seq OWNED BY public.break_.id;


--
-- Name: participant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.participant (
    id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    slack_id text NOT NULL,
    name text NOT NULL,
    email text,
    phone text,
    designation text
);


ALTER TABLE public.participant OWNER TO postgres;

--
-- Name: participant_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.participant_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.participant_id_seq OWNER TO postgres;

--
-- Name: participant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.participant_id_seq OWNED BY public.participant.id;


--
-- Name: project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.project (
    id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    started_at timestamp(3) without time zone,
    ended_at timestamp(3) without time zone,
    due_date timestamp(3) without time zone,
    title text NOT NULL,
    description text,
    participant_id integer NOT NULL
);


ALTER TABLE public.project OWNER TO postgres;

--
-- Name: project_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.project_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.project_id_seq OWNER TO postgres;

--
-- Name: project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.project_id_seq OWNED BY public.project.id;


--
-- Name: review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review (
    id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    description text NOT NULL,
    task_id integer NOT NULL,
    participant_id integer NOT NULL
);


ALTER TABLE public.review OWNER TO postgres;

--
-- Name: review_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.review_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.review_id_seq OWNER TO postgres;

--
-- Name: review_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.review_id_seq OWNED BY public.review.id;


--
-- Name: task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.task (
    id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    started_at timestamp(3) without time zone,
    ended_at timestamp(3) without time zone,
    due_date timestamp(3) without time zone,
    status integer DEFAULT 0 NOT NULL,
    title text NOT NULL,
    description text,
    participant_id integer NOT NULL,
    project_id integer NOT NULL
);


ALTER TABLE public.task OWNER TO postgres;

--
-- Name: task_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.task_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.task_id_seq OWNER TO postgres;

--
-- Name: task_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.task_id_seq OWNED BY public.task.id;


--
-- Name: team_break; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team_break (
    id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT now() NOT NULL,
    title text NOT NULL,
    break_length interval NOT NULL,
    started timestamp(3) without time zone NOT NULL,
    ended timestamp(3) without time zone
);


ALTER TABLE public.team_break OWNER TO postgres;

--
-- Name: team_break_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.team_break_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_break_id_seq OWNER TO postgres;

--
-- Name: team_break_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.team_break_id_seq OWNED BY public.team_break.id;


--
-- Name: attendance id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance ALTER COLUMN id SET DEFAULT nextval('public.attendance_id_seq'::regclass);


--
-- Name: blocker id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blocker ALTER COLUMN id SET DEFAULT nextval('public.blocker_id_seq'::regclass);


--
-- Name: break_ id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.break_ ALTER COLUMN id SET DEFAULT nextval('public.break__id_seq'::regclass);


--
-- Name: participant id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.participant ALTER COLUMN id SET DEFAULT nextval('public.participant_id_seq'::regclass);


--
-- Name: project id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project ALTER COLUMN id SET DEFAULT nextval('public.project_id_seq'::regclass);


--
-- Name: review id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review ALTER COLUMN id SET DEFAULT nextval('public.review_id_seq'::regclass);


--
-- Name: task id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task ALTER COLUMN id SET DEFAULT nextval('public.task_id_seq'::regclass);


--
-- Name: team_break id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_break ALTER COLUMN id SET DEFAULT nextval('public.team_break_id_seq'::regclass);


--
-- Data for Name: _attendanceToproject; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."_attendanceToproject" ("A", "B") FROM stdin;
\.
COPY public."_attendanceToproject" ("A", "B") FROM '$$PATH$$/3450.dat';

--
-- Data for Name: _attendanceTotask; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."_attendanceTotask" ("A", "B") FROM stdin;
\.
COPY public."_attendanceTotask" ("A", "B") FROM '$$PATH$$/3451.dat';

--
-- Data for Name: attendance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attendance (id, created_at, updated_at, in_time, out_time, on_break, participant_id) FROM stdin;
\.
COPY public.attendance (id, created_at, updated_at, in_time, out_time, on_break, participant_id) FROM '$$PATH$$/3437.dat';

--
-- Data for Name: blocker; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.blocker (id, created_at, updated_at, priority, description, project_id, participant_id) FROM stdin;
\.
COPY public.blocker (id, created_at, updated_at, priority, description, project_id, participant_id) FROM '$$PATH$$/3445.dat';

--
-- Data for Name: break_; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.break_ (id, created_at, updated_at, break_length, started, ended, attendance_id) FROM stdin;
\.
COPY public.break_ (id, created_at, updated_at, break_length, started, ended, attendance_id) FROM '$$PATH$$/3447.dat';

--
-- Data for Name: participant; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.participant (id, created_at, updated_at, slack_id, name, email, phone, designation) FROM stdin;
\.
COPY public.participant (id, created_at, updated_at, slack_id, name, email, phone, designation) FROM '$$PATH$$/3435.dat';

--
-- Data for Name: project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.project (id, created_at, updated_at, started_at, ended_at, due_date, title, description, participant_id) FROM stdin;
\.
COPY public.project (id, created_at, updated_at, started_at, ended_at, due_date, title, description, participant_id) FROM '$$PATH$$/3439.dat';

--
-- Data for Name: review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.review (id, created_at, updated_at, description, task_id, participant_id) FROM stdin;
\.
COPY public.review (id, created_at, updated_at, description, task_id, participant_id) FROM '$$PATH$$/3443.dat';

--
-- Data for Name: task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.task (id, created_at, updated_at, started_at, ended_at, due_date, status, title, description, participant_id, project_id) FROM stdin;
\.
COPY public.task (id, created_at, updated_at, started_at, ended_at, due_date, status, title, description, participant_id, project_id) FROM '$$PATH$$/3441.dat';

--
-- Data for Name: team_break; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team_break (id, created_at, updated_at, title, break_length, started, ended) FROM stdin;
\.
COPY public.team_break (id, created_at, updated_at, title, break_length, started, ended) FROM '$$PATH$$/3449.dat';

--
-- Name: attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attendance_id_seq', 44, true);


--
-- Name: blocker_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.blocker_id_seq', 8, true);


--
-- Name: break__id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.break__id_seq', 6, true);


--
-- Name: participant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.participant_id_seq', 6, true);


--
-- Name: project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.project_id_seq', 8, true);


--
-- Name: review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.review_id_seq', 39, true);


--
-- Name: task_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.task_id_seq', 50, true);


--
-- Name: team_break_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.team_break_id_seq', 1, false);


--
-- Name: attendance attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_pkey PRIMARY KEY (id);


--
-- Name: blocker blocker_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blocker
    ADD CONSTRAINT blocker_pkey PRIMARY KEY (id);


--
-- Name: break_ break__pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.break_
    ADD CONSTRAINT break__pkey PRIMARY KEY (id);


--
-- Name: participant participant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.participant
    ADD CONSTRAINT participant_pkey PRIMARY KEY (id);


--
-- Name: project project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_pkey PRIMARY KEY (id);


--
-- Name: review review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_pkey PRIMARY KEY (id);


--
-- Name: task task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_pkey PRIMARY KEY (id);


--
-- Name: team_break team_break_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team_break
    ADD CONSTRAINT team_break_pkey PRIMARY KEY (id);


--
-- Name: _attendanceToproject_AB_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "_attendanceToproject_AB_unique" ON public."_attendanceToproject" USING btree ("A", "B");


--
-- Name: _attendanceToproject_B_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "_attendanceToproject_B_index" ON public."_attendanceToproject" USING btree ("B");


--
-- Name: _attendanceTotask_AB_unique; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "_attendanceTotask_AB_unique" ON public."_attendanceTotask" USING btree ("A", "B");


--
-- Name: _attendanceTotask_B_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "_attendanceTotask_B_index" ON public."_attendanceTotask" USING btree ("B");


--
-- Name: participant_slack_id_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX participant_slack_id_key ON public.participant USING btree (slack_id);


--
-- Name: attendance set_timestamp_attendance; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_timestamp_attendance BEFORE UPDATE ON public.attendance FOR EACH ROW EXECUTE FUNCTION public.trigger_set_timestamp();


--
-- Name: blocker set_timestamp_blocker; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_timestamp_blocker BEFORE UPDATE ON public.blocker FOR EACH ROW EXECUTE FUNCTION public.trigger_set_timestamp();


--
-- Name: break_ set_timestamp_break_; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_timestamp_break_ BEFORE UPDATE ON public.break_ FOR EACH ROW EXECUTE FUNCTION public.trigger_set_timestamp();


--
-- Name: participant set_timestamp_participant; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_timestamp_participant BEFORE UPDATE ON public.participant FOR EACH ROW EXECUTE FUNCTION public.trigger_set_timestamp();


--
-- Name: project set_timestamp_project; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_timestamp_project BEFORE UPDATE ON public.project FOR EACH ROW EXECUTE FUNCTION public.trigger_set_timestamp();


--
-- Name: review set_timestamp_review; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_timestamp_review BEFORE UPDATE ON public.review FOR EACH ROW EXECUTE FUNCTION public.trigger_set_timestamp();


--
-- Name: task set_timestamp_task; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_timestamp_task BEFORE UPDATE ON public.task FOR EACH ROW EXECUTE FUNCTION public.trigger_set_timestamp();


--
-- Name: team_break set_timestamp_team_break; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER set_timestamp_team_break BEFORE UPDATE ON public.team_break FOR EACH ROW EXECUTE FUNCTION public.trigger_set_timestamp();


--
-- Name: _attendanceToproject _attendanceToproject_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_attendanceToproject"
    ADD CONSTRAINT "_attendanceToproject_A_fkey" FOREIGN KEY ("A") REFERENCES public.attendance(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _attendanceToproject _attendanceToproject_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_attendanceToproject"
    ADD CONSTRAINT "_attendanceToproject_B_fkey" FOREIGN KEY ("B") REFERENCES public.project(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _attendanceTotask _attendanceTotask_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_attendanceTotask"
    ADD CONSTRAINT "_attendanceTotask_A_fkey" FOREIGN KEY ("A") REFERENCES public.attendance(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _attendanceTotask _attendanceTotask_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_attendanceTotask"
    ADD CONSTRAINT "_attendanceTotask_B_fkey" FOREIGN KEY ("B") REFERENCES public.task(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: attendance attendance_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance
    ADD CONSTRAINT attendance_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participant(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: blocker blocker_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blocker
    ADD CONSTRAINT blocker_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participant(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: blocker blocker_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.blocker
    ADD CONSTRAINT blocker_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: break_ break__attendance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.break_
    ADD CONSTRAINT break__attendance_id_fkey FOREIGN KEY (attendance_id) REFERENCES public.attendance(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: project project_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.project
    ADD CONSTRAINT project_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participant(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: review review_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participant(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: review review_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.task(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: task task_participant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_participant_id_fkey FOREIGN KEY (participant_id) REFERENCES public.participant(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: task task_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.task
    ADD CONSTRAINT task_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.project(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

